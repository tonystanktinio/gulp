# Gulp 4 for Beginners
 
![Gulp 4 for Beginners](https://user-images.githubusercontent.com/37986728/74626528-8c67d700-5115-11ea-9a84-7467ffda7b90.png)

Hey there! 

This is the source code for the [Gulp 4 for Beginners](https://coder-coder.com/gulp-course/) course. You can use this as a simple boilerplate for front-end projects.

Once you fork/download the repo, just make sure to run `npm install` to get all the packages necessary.

Feel free to fork and share this repo!
