const testLocal = "Here's a local script file!";
console.log(testLocal);

const camelCase = require('camelcase');
const testVar = "testing camelcase in js";
console.log(camelCase(testVar));